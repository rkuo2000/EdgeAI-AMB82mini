# Example: `Ping`
